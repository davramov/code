h = 2*x*y-3*x^2-4*y^2-18*x+28*y+1200

x = linspace(0,100)
y = linspace(0,100)

