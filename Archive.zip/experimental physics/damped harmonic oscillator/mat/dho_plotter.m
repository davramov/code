plot(f,avg,'+',f1,avg1,'+',f2,avg2,'+','MarkerSize', 12)
xlabel('Frequency (Hz)')
ylabel('Amplitude (m)')
