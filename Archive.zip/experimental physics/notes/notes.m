I=I_s*(exp(((q*V)/(n*k*T))-1))
%T = temperature
%n = fudge factor
%I_s = saturation current
%I = current
%V = voltage
%q = charge of electron
%k = boltzmann's constant

%Plan for today
%1 - pi-based voltmeter
%2 - pi-controlled DC circuit
%3 - build I-V measurement

