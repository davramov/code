for i



plot(time,pressure)